#!/bin/bash

killall conky

conky -c ~/.conky/conkyrc_glass_panels ;

exit 0
